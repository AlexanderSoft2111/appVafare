var ipAddress = '192.168.192.168';
var port      = '8008';

var deviceID_printer = 'local_printer'
